<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\TempleController;
use App\Http\Controllers\Api\DeityPoojaStarController;
use App\Http\Controllers\Api\BillingController;
use App\Http\Controllers\Api\TestController;
use App\Http\Controllers\Api\DevoteeController;
use App\Http\Controllers\Api\ReportController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('/auth/register', [AuthController::class, 'createUser'])->name('register');
Route::post('/auth/login', [AuthController::class, 'loginUser'])->name('login');
Route::apiResource('temples', TempleController::class);

Route::middleware(['auth:sanctum','CheckDatabase'])->group(function () {
    Route::get('deities', [DeityPoojaStarController::class,'allDieties'])->name('deities');
    Route::get('stars', [DeityPoojaStarController::class,'allStars'])->name('stars');
    Route::get('special-stars', [DeityPoojaStarController::class,'allSpecialStars'])->name('specialStars');
    Route::get('payment-modes', [DeityPoojaStarController::class,'allPaymentModes'])->name('paymentModes');
    Route::get('quick-bill-pooja', [BillingController::class,'quickBillPooja'])->name('quickBillPooja');

    Route::post('deity/poojas', [DeityPoojaStarController::class,'deityPoojas'])->name('deity.poojas');
    Route::post('counters', [BillingController::class,'counters'])->name('counters');
    Route::post('devotees', [DevoteeController::class,'devotees'])->name('devotees');
    Route::post('create-devotee', [DevoteeController::class,'storeDevotee'])->name('devotees.store');
    Route::post('preview-bill', [BillingController::class,'previewBill'])->name('billing.previewBill');
    Route::post('save-bill', [BillingController::class,'saveBill'])->name('billing.saveBill');
    Route::post('quick-bill', [BillingController::class,'quickBill'])->name('billing.quickBill');

	Route::post('test-preview-bill', [TestController::class,'previewBill'])->name('test.previewBill');
	Route::post('test-bill', [TestController::class,'testBill'])->name('test.testBill');
    
    Route::get('bill-list', [BillingController::class,'billList'])->name('billing.billList');
    
    /* Reports Start */
    Route::get('reports/counter-wise',[ReportController::class,'counterWise'])->name('reports.counter-wise');
    Route::get('reports/daily-summary',[ReportController::class,'dailySummary'])->name('reports.daily-summary');
    Route::get('reports/daily-poojawise-summary',[ReportController::class,'dailyPoojawiseSummary'])->name('reports.daily-poojawise-summary');
    Route::get('reports/pooja-summary',[ReportController::class,'poojaSummary'])->name('reports.pooja-summary');
    Route::get('reports/bill-reprint',[ReportController::class,'billReprint'])->name('reports.bill-reprint');
    Route::get('reports/bill-details',[ReportController::class,'billDetailsbyId'])->name('reports.bill-details');
	Route::get('reports/pooja-list',[ReportController::class,'poojaList'])->name('reports.pooja-list');
    /* Reports End */
    
    
    Route::post('/auth/logout', [AuthController::class,'logout']);
});

Route::fallback(function () {
    // Return an "unauthenticated" response if the user is not authenticated
    return response()->json([
        'message' => 'Unauthenticated'
    ], 401);
});
