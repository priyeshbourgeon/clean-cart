<!DOCTYPE html>
<html>
<style>
body, html {
  height: 100%;
  margin: 0;
}

.bgimg {
  background-image: url('https://images.unsplash.com/photo-1582510003544-4d00b7f74220?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjN8fHRlbXBsZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60');
  height: 100%;
  background-position: center;
  background-size: cover;
  position: relative;
  color: white;
  font-family: "Courier New", Courier, monospace;
  font-size: 25px;
}


.middle {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}

hr {
  margin: auto;
  width: 40%;
}
</style>
<body>

<div class="bgimg">
  <div class="middle">
    <h1>PUNNYAM TEMPLE SUITE</h1>
    <hr>
    <p>Powered By Bourgeon Innovations Pvt Ltd</p>
  </div>
</div>

</body>
</html>
<?php /**PATH /home/appuser/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>