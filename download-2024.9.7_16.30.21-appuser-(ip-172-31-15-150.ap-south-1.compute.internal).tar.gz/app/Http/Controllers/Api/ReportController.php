<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PoojaSummaryResource;
use App\Http\Resources\DailySummaryResource;
use App\Models\BillingDetail;
use App\Models\Billing;
use App\Models\PaymentMode;
use App\Models\Counter;
use App\Models\Temple;
use App\Models\Diety;
use App\Models\Devotee;
use App\Models\Pooja;
use App\Models\Star;
use Illuminate\Http\Request;
use DB;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function poojaList(Request $request){
    
     $tem = Temple::where('punnyam_code',auth()->user()->punnyam_code)->first();
    
        $temple = array(
               'name' => $tem->name ?? '',
               'name_mal' => $tem->name_mal ?? '',
               'address_line_1' => $tem->address_line_1.' '.$tem->address_line_2,
               'address_line_2' => $tem->city.' '.$tem->state.' '.$tem->pincode,
               'phone' => $tem->mobile,
               'email' => $tem->email,
               'website' => $tem->website
            );
    
        $data = [];
        $deities = BillingDetail::selectRaw('diety.id,diety.name')
                                  ->distinct()
        						  ->leftJoin('billing','billing.id','billing_dtls.bill_id')
        						  ->leftJoin('diety','diety.id','billing_dtls.diety_id')
        						  ->whereDate('billing_dtls.date',today())
                                  ->where('billing.deleted','0')
                                 ->get();
        foreach($deities as $deity){
             array_push($data,array(
                                'diety_name' => $deity->name,
                                'diety_id' => $deity->id,
                                'poojas' => $this->getPoojas($deity->id),
             ));
        }
        
        
                               
        return response()->json([
           'status' => true,
           'temple' => $temple,
           'pooja_list' => $data,
           'message' => 'Fetched Pooja List'
        ]);
    }
                        
    public function getPoojas($deity_id){
         $data = BillingDetail::select('pooja.id', 'pooja.name as pooja_name')
         					->distinct()
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            ->leftJoin('diety','diety.id','billing_dtls.diety_id')
                            ->leftJoin('pooja','pooja.id','billing_dtls.pooja')
                            ->whereDate('billing_dtls.date',today())
                            ->where('billing.deleted','0')
                            ->where('billing_dtls.diety_id',$deity_id)
         					->where('billing.pos_user_id', auth()->user()->id)
                            ->get();   
    
          $poojas = [];
    	  foreach($data as $pooja){
              array_push($poojas,array(
                                'pooja_name' => $pooja->pooja_name,
                                'pooja_id' => $pooja->id,
                                'bills' => $this->getBills($deity_id,$pooja->id),
              ));
          }
    
          return $poojas;
    
    }

    public function getBills($deity_id,$pooja_id){
    		$data = BillingDetail::select('billing_dtls.*','billing.id as bill_no','stars.name_mal as star_name')
         					->distinct()
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            ->leftJoin('diety','diety.id','billing_dtls.diety_id')
                            ->leftJoin('pooja','pooja.id','billing_dtls.pooja')
            				->leftJoin('stars','stars.id','billing_dtls.star')
                            ->whereDate('billing_dtls.date',today())
                            ->where('billing.deleted','0')
                            ->where('billing_dtls.diety_id',$deity_id)
                            ->where('billing_dtls.pooja',$pooja_id)
            				->where('billing.pos_user_id', auth()->user()->id)
                            ->get();   
    
          $bills = [];
    	  foreach($data as $bill){
              array_push($bills,array(
                                'bill_no' => 'Bill-'.$bill->bill_no,
                                'name' => $bill->name,
                                'star' => $bill->star_name,
              					'time' => $bill->time,
                                'nos' => $bill->qlt
                                
              ));
          }
    
          return $bills;
    }
    
    public function counterWise(Request $request){
        $targetDate = $request->from_date; 
        $targetCounterId = $request->counter_id; 
        
        $counter = Counter::find($targetCounterId);
        
        if(!$counter){
             return response()->json([
                'status' => false,
                'message' => 'Counter Not Found!'
            ]);
        }
        
        $paymentModes = PaymentMode::with(['billings' => function ($query) use ($targetDate, $targetCounterId) {
            $query->selectRaw('mode, SUM(recv_amt) as total_amount')
                ->where('date', $targetDate)
                ->where('counter', $targetCounterId)
            	->where('pos_user_id', auth()->user()->id)
            	->where('deleted', 0)
                ->groupBy('mode');
        }])->get();
        
        
        $collection = [];
        $total_collection = 0;
        foreach ($paymentModes as $paymentMode) {
            $billing = $paymentMode->billings->first();
        	$amount  = $billing ? $billing->total_amount : 0;
            $collection[] = [
                'payment_mode' => $paymentMode->name,
                'total_amount' => (string)$amount,
            ];
            
            $total_collection += ($amount);
        }
        
        return response()->json([
            'status' => true,
            'selected_date' => $targetDate,
            'counter' => $counter->name,
            'data' => $collection,
            'total_collection' => (string)$total_collection
        ]);
        
    } 
    
    public function dailySummary(Request $request){
        $query = BillingDetail::selectRaw('pooja.id,pooja.name as pooja_name,billing_dtls.qlt as quantity,billing_dtls.rate,billing_dtls.postal_amt,billing_dtls.amount ')
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            ->leftJoin('diety','diety.id','billing_dtls.diety_id')
                            ->leftJoin('pooja','pooja.id','billing_dtls.pooja');
    	$query->where('billing.pos_user_id', auth()->user()->id);
        if(!is_null($request->from_date) && !is_null($request->to_date)){
            $query->whereBetween('billing.date',[$request->from_date,$request->to_date]);
        }
        if(!is_null($request->diety_id)){
            $query->where('billing_dtls.diety_id',$request->diety_id);
        }
        
        $summaries = $query->paginate(10);
        return response()->json([
            'status' => true,
            'data' => DailySummaryResource::collection($summaries),
            'meta' => [
                'total' => $summaries->total(),
                'per_page' => $summaries->perPage(),
                'current_page' => $summaries->currentPage(),
                'last_page' => $summaries->lastPage(),
                'next_page_url' => $summaries->nextPageUrl(),
                'prev_page_url' => $summaries->previousPageUrl(),
                'from' => $summaries->firstItem(),
                'to' => $summaries->lastItem()
            ],
            'links' => [
                'self' => $summaries->url($summaries->currentPage()),
                'first' => $summaries->url(1),
                'last' => $summaries->url($summaries->lastPage()),
                'prev' => $summaries->previousPageUrl(),
                'next' => $summaries->nextPageUrl()
            ]
        ]);
        
    } 
    
    

    public function poojaSummary(Request $request)
    {
        try {
            // $query = BillingDetail::selectRaw('pooja.name as pooja_name, SUM(billing_dtls.qlt) as pooja_count,SUM(billing_dtls.rate) AS total_rate')
            //     ->leftJoin('pooja', 'pooja.id', '=', 'billing_dtls.pooja');
    
            $query = BillingDetail::selectRaw('pooja.name as pooja_name, SUM(billing_dtls.qlt) as pooja_count,SUM(billing_dtls.amount) AS total_rate')
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            // ->leftJoin('diety','diety.id','billing_dtls.diety_id')
                            ->leftJoin('pooja','pooja.id','billing_dtls.pooja');
       
             $query->where('billing.pos_user_id', auth()->user()->id);               
            if(!is_null($request->from_date) && !is_null($request->to_date)){
                $query->whereBetween('billing.date',[$request->from_date,$request->to_date]);
            }
        
        	$query->where('billing.deleted', 0);
            $gross_total = $query->get()->sum('total_rate');
            
            $poojaSummaries = $query->groupBy('billing_dtls.pooja')
                ->get();
        
        $tem = Temple::where('punnyam_code',auth()->user()->punnyam_code)->first();
    
        $temple = array(
               'name' => $tem->name ?? '',
               'name_mal' => $tem->name_mal ?? '',
               'address_line_1' => $tem->address_line_1.' '.$tem->address_line_2,
               'address_line_2' => $tem->city.' '.$tem->state.' '.$tem->pincode,
               'phone' => $tem->mobile,
               'email' => $tem->email,
               'website' => $tem->website
            );
        
            return response()->json([
                'status' => true,
                'temple' => $temple,
                'data' => PoojaSummaryResource::collection($poojaSummaries),
                'gross_total' => strval($gross_total),//(string)$poojaSummaries->sum('total_rate'),
                // 'meta' => [
                //     'total' => $poojaSummaries->total(),
                //     'per_page' => $poojaSummaries->perPage(),
                //     'current_page' => $poojaSummaries->currentPage(),
                //     'last_page' => $poojaSummaries->lastPage(),
                //     'next_page_url' => $poojaSummaries->nextPageUrl(),
                //     'prev_page_url' => $poojaSummaries->previousPageUrl(),
                //     'from' => $poojaSummaries->firstItem(),
                //     'to' => $poojaSummaries->lastItem()
                // ],
                // 'links' => [
                //     'self' => $poojaSummaries->url($poojaSummaries->currentPage()),
                //     'first' => $poojaSummaries->url(1),
                //     'last' => $poojaSummaries->url($poojaSummaries->lastPage()),
                //     'prev' => $poojaSummaries->previousPageUrl(),
                //     'next' => $poojaSummaries->nextPageUrl()
                // ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while fetching pooja summaries.',
                'error' => $e->getMessage()
            ]);
        }
    }

    
    public function billReprint(Request $request){
        $query = BillingDetail::selectRaw('billing.date,billing.diety_id,billing.id as bill_no,diety.name as dietyname,billing.total,billing_dtls.postal_amt,billing.recv_amt,billing.bal_amt,billing.mode ')
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            ->leftJoin('diety','diety.id','billing_dtls.diety_id');
        if(!is_null($request->from_date) && !is_null($request->to_date)){
            $query->whereBetween('billing.date',[$request->from_date,$request->to_date]);
        }
        if(!is_null($request->diety_id)){
            $query->where('billing.diety_id',$request->diety_id);
        }
        if(!is_null($request->bill_no)){
            $query->where('billing.id',$request->bill_no);
        }
        if(!is_null($request->mode)){
            $query->where('billing.mode',$request->mode);
        }
        
        $billreprint = $query->paginate(10);
        return response()->json([
            'status' => true,
            'data' => $billreprint
        ]);
        
    } 
    
        
    public function billDetailsbyId(Request $request){
        $bill = Billing::find($request->id);
        $bill_data = array(
                         'bill_id' => $bill->id,
                         'bill_date' => $bill->bill_time,
                         'counter' => $this->counter_details($bill->counter),
                         'devotee' => $this->customer_details($bill->customer_id),
                         'payment_mode' => $this->payment_mode_details($bill->mode),
                         'total' => $bill->total
                    );
        $query = BillingDetail::selectRaw(' diety.name as dietyname,
                                            diety.name_mal as dietyname_mal,
                                            pooja.name as poojaname,
                                            pooja.name_mal as poojaname_mal,
                                            billing_dtls.name,
                                            stars.name_eng as starname,
                                            stars.name_mal as starname_mal,
                                            billing_dtls.qlt as quantity,
                                            billing_dtls.rate,
                                            billing_dtls.amount as total,
                                            billing_dtls.time,
                                            billing_dtls.date as pooja_date ')
                            ->leftJoin('billing','billing.id','billing_dtls.bill_id')
                            ->leftJoin('diety','diety.id','billing_dtls.diety_id')
                            ->leftJoin('pooja','pooja.id','billing_dtls.pooja')
                            ->leftJoin('stars','stars.id','billing_dtls.star')
                            ->where('billing.id',$request->id);
                            
        $billdetails = $query->get();
        
        $tem = Temple::where('punnyam_code',auth()->user()->punnyam_code)->first();
        
        $temple = array(
               'name' => $tem->name ?? '',
               'name_mal' => $tem->name_mal ?? '',
               'address_line_1' => $tem->address_line_1.' '.$tem->address_line_2,
               'address_line_2' => $tem->city.' '.$tem->state.' '.$tem->pincode,
               'phone' => $tem->mobile,
               'email' => $tem->email,
               'website' => $tem->website
            );
        return response()->json([
            'status' => true,
            'temple' => $temple,
            'bill_summary' => $bill_data,
            'bill_details' => $billdetails
        ]);
    }
    
    
    
    
    public function dailyPoojawiseSummary(Request $request){
        
    } 
     
    public function index()
    {
        $temples = Temple::all('id','name','punnyam_code');

        return response()->json([
            'status' => true,
            'data' => $temples
        ]);
    }
    
     public function customer_details($id){
        return Devotee::find($id)->name ?? 'Walk-in Devotee';
    }

    public function counter_details($id){
        return Counter::find($id)->name ?? '';
    }

    public function payment_mode_details($id){
        return PaymentMode::find($id)->name ?? '';
    }

 
}
